import pygame
from os.path import join
from os import walk

LARGURA_TELA, ALTURA_TELA = 1280,720
TAMANHO_TELA = 64
